package com.woniu.myspringmvc.controller;

public class GoodStore {

}

package com.woniu.myspringmvc.controller;

import java.math.BigDecimal;

import javax.servlet.http.HttpServletRequest;

import com.woniu.myspringmvc.annotation.Controller;
import com.woniu.myspringmvc.annotation.RequestMapping;
import com.woniu.myspringmvc.annotation.ResponseForward;
import com.woniu.myspringmvc.annotation.ResponseRedirect;

@Controller
@RequestMapping(value = "/login")
public class Goods {
	@RequestMapping(value = "/user")
	public void login(HttpServletRequest request) {
		System.out.println("login" + request);
	}

	@RequestMapping(value = "/hello")
	public void hello(byte b, short s, int i, long l, float f, double d, char c, boolean bln, String str,
			BigDecimal big, String[] strs, int[] is) {
		System.out.println(b);
		System.out.println(s);
		System.out.println(i);
		System.out.println(l);
		System.out.println(f);
		System.out.println(d);
		System.out.println(c);
		System.out.println(bln);
		System.out.println(str);
		System.out.println(big);
		for (String j : strs) {
			System.out.println(j);
		}
		for (int j : is) {
			System.out.println(j);
		}
	}

	@RequestMapping(value = "/demo")
	public void demo(Demo demo) {
		System.out.println(demo);
	}

	@RequestMapping(value = "/redirect")
	@ResponseRedirect
	public  String redirect() {
		return "cesi.jsp";
	}
	@RequestMapping(value = "/forward")
	@ResponseForward
	public  String forward() {
		return "WEB-INF/jsp/cesi.jsp";
	}
}

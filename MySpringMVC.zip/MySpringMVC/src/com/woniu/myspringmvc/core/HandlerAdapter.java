package com.woniu.myspringmvc.core;

import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import java.math.BigDecimal;
import java.util.Enumeration;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.bind.ParseConversionEvent;

public class HandlerAdapter {
	private HandlerMapping handlerMapping;
	private Object invoke;
	public HandlerAdapter(HandlerMapping handlerMapping) {
		this.handlerMapping = handlerMapping;
	}
	public Object adapter(HttpServletRequest request,HttpServletResponse response) {
		
		//获取请求URI信息
		String requestURI = request.getRequestURI();
		//获取路径
		int indexOf = requestURI.indexOf("controller");
		String key = requestURI.substring(indexOf+10);
			//获取controller对象
			Class object = (Class) HandlerMapping.getControllerMapping().get(key);
			//获取方法
			Method method = (Method) HandlerMapping.getMethodMapping().get(key);	
			//获取形参个数
			int methodParamCount = method.getParameterCount();
			//存储方法实参
			Object[] realMethodParam = new Object[methodParamCount];
			//获取客户端参数
			Map<String, String[]> requestParameterMap = request.getParameterMap();
			//判断目标方法是否存在request或respon参数
			//获取目标方法参数
			Parameter[] methodParameters = method.getParameters();
			//遍历
			for (int i = 0; i < methodParameters.length; i++) {
				//取出每个方法参数
				Parameter methodParam = methodParameters[i];
				//获取参数类型
				Class<?> methodParamTypeCl = methodParam.getType();
				//判断参数类型
				//判断当前class是否为指定类型的class或者父类
				if (methodParamTypeCl.isAssignableFrom(HttpServletRequest.class)) {
					realMethodParam[i] = request;
				}
				if (methodParamTypeCl.isAssignableFrom(HttpServletResponse.class)) {
					realMethodParam[i] = response;
				}
				//根据方法参数名称获取客户端传参值，并进行类型转换(String转为方法参数对应类型)
				//将转换后的值存储到对应实参数组
				//判断形参是否是基本数据类型 字符串类型，数组类型
				if (methodParamTypeCl.isPrimitive()
						||methodParamTypeCl.isAssignableFrom(String.class)
						||methodParamTypeCl.isArray()
						||methodParamTypeCl.isAssignableFrom(BigDecimal.class)) {
					
					//Object attribute = request.getAttribute(methodParam);
					//realMethodParam[i] = attribute;
					//获取参数名称
					String paramName = methodParam.getName();
					//从请求中获取客户端传参
					String[] requestParam = requestParameterMap.get(paramName);
					if (requestParam==null) {
						try {
							response.sendError(888,"客户端未传"+paramName+"参数值");
						} catch (IOException e) {
							e.printStackTrace();
						}
					}
					realMethodParam[i] = Parse(requestParam,methodParamTypeCl);
				}
				if (methodParamTypeCl.getClassLoader()!=null) {
					/*获取目标类所有属性，拼接键(参数名称.属性名称)，尝试从请求中获取参数值，
					 如果有，则赋值给对应变量，没有，则不操作，最终将赋值的对象赋给实参数组*/
					//获取方法参数名称
					String methodParamName =  methodParam.getName();
					//获取目标参数类型的所有属性
					Field[] methodParamFields = methodParamTypeCl.getDeclaredFields();
					//创建目标对象
					Object obj = null;
					try {
						obj = methodParamTypeCl.newInstance();
					} catch (InstantiationException e) {
						e.printStackTrace();
					} catch (IllegalAccessException e) {
						e.printStackTrace();
					}
					for (Field field : methodParamFields) {
						//获取属性名称
						String methodParamFieldName = field.getName();
						//获取键demo.id
						String keyss = methodParamName+"."+methodParamFieldName;
						//根据键取实参
						String[] requestParam = requestParameterMap.get(keyss);
						if (requestParam==null) {
							continue;
						}
						//获取属性类型
						Class<?> type = field.getType();
						//将String参数转换成实际参数类型
						Object re = Parse(requestParam, type);
						//获取set方法名称
						String setMethod="set"+methodParamFieldName.substring(0,1).toUpperCase()+methodParamFieldName.substring(1);
						//获取set方法对象
						try {
							Method setFieldMethod = methodParamTypeCl.getDeclaredMethod(setMethod,type);
							try {
								setFieldMethod.invoke(obj, re);
							} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
								continue;
							}
						} catch (NoSuchMethodException e) {		
							e.printStackTrace();
						} catch (SecurityException e) {			
							e.printStackTrace();
						}
						
					}
					realMethodParam[i]=obj;
				}
			}
			
			try {
				invoke = method.invoke(object.newInstance(),realMethodParam);
				
			} catch (IllegalAccessException e) {
				e.printStackTrace();
			} catch (IllegalArgumentException e) {
				e.printStackTrace();
			} catch (InvocationTargetException e) {
				e.printStackTrace();
			} catch (InstantiationException e) {
				e.printStackTrace();
			}
		return invoke;
	}
	private Object Parse(String[] requestParam, Class<?> methodParamTypeCl) {
		Object result=null;
		boolean isArray = false;
		if (methodParamTypeCl.isArray()) {
			isArray = true;
			methodParamTypeCl = methodParamTypeCl.getComponentType();
		}
		
		if (methodParamTypeCl.isAssignableFrom(byte.class)) {
			if (isArray) {
				byte[] re = new byte[requestParam.length];
				for (int i = 0; i < re.length; i++) {
					re[i] = Byte.parseByte(requestParam[i]);
				}
				result=re;
			}else {
				result = Byte.parseByte(requestParam[0]);
			}
		}else if (methodParamTypeCl.isAssignableFrom(short.class)) {
			if (isArray) {
				short[] re = new short[requestParam.length];
				for (int i = 0; i < re.length; i++) {
					re[i] = Short.parseShort(requestParam[0]);
				}
				result=re;
			}else {				
				result = Short.parseShort(requestParam[0]);
			}
		}else if (methodParamTypeCl.isAssignableFrom(int.class)) {
			if (isArray) {
				int[] re = new int[requestParam.length];
				for (int i = 0; i < re.length; i++) {
					re[i] = Integer.parseInt(requestParam[0]);
				}
				result=re;
			}else {				
				result = Integer.parseInt(requestParam[0]);
			}	
		}else if (methodParamTypeCl.isAssignableFrom(long.class)) {
			if (isArray) {
				long[] re = new long[requestParam.length];
				for (int i = 0; i < re.length; i++) {
					re[i] = Long.parseLong(requestParam[0]);
				}
				result=re;
			}else {				
				result = Long.parseLong(requestParam[0]);
			}	
		}else if (methodParamTypeCl.isAssignableFrom(float.class)) {
			if (isArray) {
				float[] re = new float[requestParam.length];
				for (int i = 0; i < re.length; i++) {
					re[i] = Float.parseFloat(requestParam[0]);
				}
				result=re;
			}else {				
				result = Float.parseFloat(requestParam[0]);
			}		
		}else if (methodParamTypeCl.isAssignableFrom(double.class)) {
			if (isArray) {
				double[] re = new double[requestParam.length];
				for (int i = 0; i < re.length; i++) {
					re[i] = Double.parseDouble(requestParam[0]);
				}
				result=re;
			}else {				
				result = Double.parseDouble(requestParam[0]);
			}	
		}else if (methodParamTypeCl.isAssignableFrom(char.class)) {
			if (isArray) {
				char[] re = new char[requestParam.length];
				for (int i = 0; i < re.length; i++) {
					re[i] = requestParam[i].charAt(0);
				}
				result=re;
			}else {				
				result = requestParam[0].charAt(0);
			}
			
		}else if (methodParamTypeCl.isAssignableFrom(boolean.class)) {
			if (isArray) {
				boolean[] re = new boolean[requestParam.length];
				for (int i = 0; i < re.length; i++) {
					re[i] =Boolean.parseBoolean(requestParam[i]);
				}
				result=re;
			}else {				
				result = Boolean.parseBoolean(requestParam[0]);
				}
		}else if (methodParamTypeCl.isAssignableFrom(String.class)) {
			if (isArray) {
				result=requestParam;
			}else {				
				result = requestParam[0];
				}
			
		}else if (methodParamTypeCl.isAssignableFrom(BigDecimal.class)) {
			if (isArray) {
				BigDecimal[] re = new BigDecimal[requestParam.length];
				for (int i = 0; i < re.length; i++) {
					re[i] = new BigDecimal(requestParam[0]);
				}
				result=re;
			}else {				
				result = new BigDecimal(requestParam[0]);
				}
		}
		
		return result;
	}
}

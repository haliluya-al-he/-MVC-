package com.woniu.myspringmvc.core;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sun.corba.se.spi.orbutil.fsm.Guard.Result;
import com.woniu.myspringmvc.annotation.Controller;
import com.woniu.myspringmvc.annotation.RequestMapping;
import com.woniu.myspringmvc.annotation.ResponseForward;
import com.woniu.myspringmvc.annotation.ResponseRedirect;

/*@WebServlet("/DispatcherServlet")*/
public class DispatcherServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Properties application;
	//存储类全名+/
	private List<String> classname = new ArrayList();
	private HandlerMapping handlerMapping;
	private HandlerAdapter handlerAdapter;
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("执行了service");
		//根据请求适配执行对应方法
		Object result = handlerAdapter.adapter(request, response);
		if (result==null) {
			return;
		}
		//判断目标方法上是否存在@ResponseForward或@ResponseRedirect注解，
		//如果有，分别对返回值进行重定向或请求转发
		//获取请求映射
		String pattern = request.getPathInfo();
		//根据请求映射获取目标方法
		Method method = (Method) handlerMapping.getMethodMapping().get(pattern);
		//根据方法上存在的注解
		if (method.isAnnotationPresent(ResponseForward.class)) {
			//将类型转换成String类型
			String path = (String)result;
			//请求转发
			request.getRequestDispatcher("../../"+path).forward(request, response);
		}
		//如果是重定向注解
		if (method.isAnnotationPresent(ResponseRedirect.class)) {
			//将类型转换成String类型
			System.out.println(result);
			String path = (String)result;
			//重定向转发
			response.sendRedirect("../../"+path);
		}
	
	}


	

	@Override
	public void init() throws ServletException {
			//获取配置文件
			String packageName = doLoadConfig();
			
			if (packageName==null) {
				return;
			}
			//获取指定包下的所有的类名
			getClassName(packageName);
			//创建处理器映射器对象
			handlerMapping = new HandlerMapping(classname);
			//创建处理器适配器对象
			handlerAdapter = new HandlerAdapter(handlerMapping);
		}
	
	private void getClassName(String packageName) {
		//将包名转换为文件格式	
		String filePath = packageName.replaceAll("\\.", "/");
		//获取文件真实路径
		String path = DispatcherServlet.class.getClassLoader().getResource(filePath).getPath();
		//创建File对象
		File file = new File(path);
		//获取子文件
		File[] listFiles = file.listFiles();
		if (listFiles==null) {
			return;
		}
		for (File file2 : listFiles) {
			//获取文件名称
			String finaName = file2.getName();
			if (file2.isDirectory()) {
				getClassName(packageName+"."+finaName);
			}else {
				//判断是否为字节码文件
				if (!finaName.endsWith(".class")) {
					continue;
				}
				//获取类名
				String className = finaName.replaceAll(".class", "");
				//获取类全名
				String classAllName = packageName+"."+className;
				//存储类全名
				classname.add(classAllName);
			}
		}
		//com.woniu.myspringmvc.controller
			//获取指定路径下所有文件
	}
	private String doLoadConfig() {
		//获取当前servletconfig对象
		ServletConfig config = getServletConfig();
		//获取初始化参数信息
		String configName = config.getInitParameter("controller");
		if (configName==null) {
			configName = "application.properties";
		}
		//创建properties对象
		application = new Properties();
		//加载properties文件
		InputStream is = DispatcherServlet.class.getClassLoader().getResourceAsStream(configName);
		
		try {
			application.load(is);
		} catch (IOException e) {
			e.printStackTrace();
		}finally {
			if (is!=null) {
				try {
					is.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		//获取properties文件中配置的包名
		String propertyName = application.getProperty("package");
		return propertyName;
	}
	

}

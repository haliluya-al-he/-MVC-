package com.woniu.myspringmvc.core;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.woniu.myspringmvc.annotation.Controller;
import com.woniu.myspringmvc.annotation.RequestMapping;

public class HandlerMapping {
		//存储Controller实例
		private Map<String, Object> map = new HashMap<String, Object>();
		//存储请求映射与controller的对应关系
		private static Map<String, Object> controllerMapping = new HashMap<>();
		//存储请求映射与方法对应的关系
		private static Map<String, Object> methodMapping = new HashMap<>();
		public HandlerMapping(List<String> className) {
			//实例化对象
			doInstance(className);
			//映射关系建立
			initMapping();
		}
		
		private void doInstance(List<String> classname) {
			//遍历类全名
			for (String string : classname) {
				try {
					Class<?> clazz = Class.forName(string);
					//判断clazz上是否存在Controller注解
					boolean isController = clazz.isAnnotationPresent(Controller.class);
					//如果存在，则创建对象并按类名小驼峰形式作为键，对象作为值方式存储
					if (isController) {
						try {
							//创建对象
							Object newInstance = clazz.newInstance();
							//获取最后次点的索引
							int lastIndexOf = string.lastIndexOf(".");
							//从类全名中截取类名
							String className = string.substring(lastIndexOf+1);
							//变成小驼峰
							String s= className.charAt(0)+"";
							String replaceFirst = className.replaceFirst(s, s.toLowerCase());
							//存储
							map.put(replaceFirst, newInstance);
						} catch (InstantiationException e) {
							e.printStackTrace();
						} catch (IllegalAccessException e) {
							e.printStackTrace();
						}
					}
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
		}
		private void initMapping() {
			//获取所有Controller对象
			for (Object obje : map.values()) {
				//获取controller的class实例
				Class clazz = obje.getClass();
				//判断当前类上是否存在RequestMapping注解
				if (!clazz.isAnnotationPresent(RequestMapping.class)) {
					continue;
				}
				//获取当前controller的requestmapping注解
				RequestMapping controllerRM = (RequestMapping)clazz.getDeclaredAnnotation(RequestMapping.class);
				//h获取当前controller映射值
				String controllerRMVu = controllerRM.value();
				//获取当前clazz对象所有方法
				Method[] methods = clazz.getDeclaredMethods();
				for (Method method : methods) {
					//判断方法上是否存在RequestMapping注解
					if (!method.isAnnotationPresent(RequestMapping.class)) {
						continue;
					}
					//获取当前方法上ruquestmapping注解
					RequestMapping declaredAnnotation = method.getDeclaredAnnotation(RequestMapping.class);
					//获取requestmapping注解值
					String methodValue = declaredAnnotation.value();
					//判断值是否有效
					if (controllerRMVu.length()<1 || methodValue.length()<1) {
						continue;
					}
					//键
					String key = controllerRMVu+methodValue;
					//建立请求映射与controller关系
					controllerMapping.put(key, clazz);
					//建立请求映射与Method关系
					methodMapping.put(key, method);
				}
				
			}
			
		}

		public Map<String, Object> getMap() {
			return map;
		}

		public void setMap(Map<String, Object> map) {
			this.map = map;
		}

		public static Map<String, Object> getControllerMapping() {
			return controllerMapping;
		}

		public void setControllerMapping(Map<String, Object> controllerMapping) {
			this.controllerMapping = controllerMapping;
		}

		public static Map<String, Object> getMethodMapping() {
			return methodMapping;
		}

		public void setMethodMapping(Map<String, Object> methodMapping) {
			this.methodMapping = methodMapping;
		}
		
}
